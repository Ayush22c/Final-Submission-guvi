import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainbodyuserComponent } from './mainbodyuser.component';

describe('MainbodyuserComponent', () => {
  let component: MainbodyuserComponent;
  let fixture: ComponentFixture<MainbodyuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainbodyuserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MainbodyuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
