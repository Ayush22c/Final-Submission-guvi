import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { DataService } from '../Services/data.service';

@Component({
  selector: 'app-mainbodyuser',
  templateUrl: './mainbodyuser.component.html',
  styleUrls: ['./mainbodyuser.component.css']
})
export class MainbodyuserComponent implements OnInit {

  init:boolean=true;
  arr:any=[];

  val:number=0;

  constructor(private dataobj:DataService,private route:Router) {
    localStorage.setItem('movie',JSON.stringify({}));
   }


  ngOnInit(): void {
    this.dataobj.getMovieDetail().subscribe((data:any) => {
      this.arr = data;
     if(this.arr.length > 0)
      this.init = false;
    });
  }

  // nextpage(obj:){
  //   localStorage.setItem('movie',JSON.stringify(obj));
  //   console.log("hi")
  // }

  nextpage(obj:any){
    console.log(obj)
    localStorage.setItem('movie',JSON.stringify(obj));
  }
}
