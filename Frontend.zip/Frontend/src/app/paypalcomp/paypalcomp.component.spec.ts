import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaypalcompComponent } from './paypalcomp.component';

describe('PaypalcompComponent', () => {
  let component: PaypalcompComponent;
  let fixture: ComponentFixture<PaypalcompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaypalcompComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaypalcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
