import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paypalcomp',
  templateUrl: './paypalcomp.component.html',
  styleUrls: ['./paypalcomp.component.css']
})
export class PaypalcompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    console.log(window.paypal)
    paypal.Buttons({
      style:{
        layout: 'vertical',
    color:  'blue',
    shape:  'rect',
    label:  'paypal'
      }
    }).render('#paypal-button-container')
  }

}
