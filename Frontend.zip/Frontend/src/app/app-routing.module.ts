import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { BookinggridComponent } from './bookinggrid/bookinggrid.component';
import { CutomergridComponent } from './cutomergrid/cutomergrid.component';
import { DefaultpageComponent } from './defaultpage/defaultpage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { MainbodydefaultComponent } from './mainbodydefault/mainbodydefault.component';
import { MoivegridComponent } from './moivegrid/moivegrid.component';
import { OfferpagedefaultComponent } from './offerpagedefault/offerpagedefault.component';
import { OfferspageComponent } from './offerspage/offerspage.component';
import { PaymentgridadminComponent } from './paymentgridadmin/paymentgridadmin.component';
import { PaymentgriduserComponent } from './paymentgriduser/paymentgriduser.component';
import { PaymentpageComponent } from './paymentpage/paymentpage.component';
import { PaypalcompComponent } from './paypalcomp/paypalcomp.component';
import { SeatbookingComponent } from './seatbooking/seatbooking.component';
import { UserpageComponent } from './userpage/userpage.component';

const routes: Routes = [
  { path: '', component: DefaultpageComponent },
  { path: 'home', component: DefaultpageComponent },
  { path: 'mainbody', component: MainbodydefaultComponent },
  { path: 'loginpage', component: LoginpageComponent },
  { path: 'admin', component: AdminpageComponent },
  { path: 'user', component: UserpageComponent },
  {path:'movielist',component:MoivegridComponent},
  {path:'customerlist',component:CutomergridComponent},
  {path:'paymentadmin',component:PaymentgridadminComponent},
  {path:'booking',component:BookinggridComponent},
  {path:'paymentuser',component:PaymentgriduserComponent},
  {path:'offers',component:OfferspageComponent},
  {path:'seatbooking',component:SeatbookingComponent},
  {path:'offersdef',component:OfferpagedefaultComponent},
  {path:'submit',component:PaymentpageComponent},
  {path:'paypalcomp',component:PaypalcompComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
