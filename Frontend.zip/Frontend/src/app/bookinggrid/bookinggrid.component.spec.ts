import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookinggridComponent } from './bookinggrid.component';

describe('BookinggridComponent', () => {
  let component: BookinggridComponent;
  let fixture: ComponentFixture<BookinggridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookinggridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookinggridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
