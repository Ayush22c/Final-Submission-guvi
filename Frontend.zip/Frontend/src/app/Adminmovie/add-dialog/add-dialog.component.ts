import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-dialog',
  templateUrl: './add-dialog.component.html',
  styleUrls: ['./add-dialog.component.css']
})
export class AddDialogComponent implements OnInit {

  morning:number=0;
  noon:number=0;
  evening:number=0;
  mornprice:number=0;
  noonprice:number=0;
  evenprice:number=0;
  UserData : any={
    id: '',
    movie_name:"",
	  seats:[],
    timings:["Morning","Noon","Evening"],
    ratings:"",
	  image:"",
	  price: [],
	  description: "",
	  genre: "",
	  language:"",
	  origin:"",
	  trailer:"",
  }
  constructor(private dialogRef: MatDialogRef<AddDialogComponent>) { }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close({valid: false,value:this.UserData});
  }
  doneChange(){
    this.UserData.seats=[this.morning,this.noon,this.evening];
    this.UserData.price=[this.mornprice,this.noonprice,this.evenprice];
    this.dialogRef.close({valid: true,value:this.UserData});
  }

}
