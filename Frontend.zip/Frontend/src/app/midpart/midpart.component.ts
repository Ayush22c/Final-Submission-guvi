import { Component, Input, OnInit } from '@angular/core';
import { DataService } from '../Services/data.service';

@Component({
  selector: 'app-midpart',
  templateUrl: './midpart.component.html',
  styleUrls: ['./midpart.component.css']
})
export class MidpartComponent implements OnInit {

  init:boolean=true;
  arr:any=[];

  @Input() item:any;
  constructor(private dataobj:DataService) { }

  ngOnInit(): void {
    this.dataobj.getMovieDetail().subscribe((data:any) => {
      this.arr = data;
     if(this.arr.length > 0)
      this.init = false;
    });
  }

}
