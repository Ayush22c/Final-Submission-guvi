import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DataService } from '../Services/data.service';

@Component({
  selector: 'app-mainbodydefault',
  templateUrl: './mainbodydefault.component.html',
  styleUrls: ['./mainbodydefault.component.css']
})
export class MainbodydefaultComponent implements OnInit {

  init:boolean=true;
  arr:any=[];
  constructor(private dataobj:DataService,public  snackbar: MatSnackBar) { }

  ngOnInit(): void {
    this.dataobj.getMovieDetail().subscribe((data:any) => {
      this.arr = data;
     if(this.arr.length > 0)
      this.init = false;
    });
  }

  func(){
    alert("Please Sign in...")

    console.log(true)
    // })
  }





}
