import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainbodydefaultComponent } from './mainbodydefault.component';

describe('MainbodydefaultComponent', () => {
  let component: MainbodydefaultComponent;
  let fixture: ComponentFixture<MainbodydefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainbodydefaultComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MainbodydefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
