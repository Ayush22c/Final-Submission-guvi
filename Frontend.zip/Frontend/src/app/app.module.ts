import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { BookinggridComponent } from './bookinggrid/bookinggrid.component';
import { CutomergridComponent } from './cutomergrid/cutomergrid.component';
import { DefaultpageComponent } from './defaultpage/defaultpage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { MainbodyadminComponent } from './mainbodyadmin/mainbodyadmin.component';
import { MainbodydefaultComponent } from './mainbodydefault/mainbodydefault.component';
import { MoivegridComponent } from './moivegrid/moivegrid.component';
import { NavadminComponent } from './navadmin/navadmin.component';
import { NavuserComponent } from './navuser/navuser.component';
import { OfferspageComponent } from './offerspage/offerspage.component';
import { PaymentgriduserComponent } from './paymentgriduser/paymentgriduser.component';
import { PaymentgridadminComponent } from './paymentgridadmin/paymentgridadmin.component';
import { SeatbookingComponent } from './seatbooking/seatbooking.component';
import { UserpageComponent } from './userpage/userpage.component';
import { NavdeafultComponent } from './navdeafult/navdeafult.component';

import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MainbodyuserComponent } from './mainbodyuser/mainbodyuser.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MidpartComponent } from './midpart/midpart.component';
import { OfferpagedefaultComponent } from './offerpagedefault/offerpagedefault.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { PaymentpageComponent } from './paymentpage/paymentpage.component';
import { AddDialogComponent } from './Adminmovie/add-dialog/add-dialog.component';
import { DeleteDialogComponent } from './Adminmovie/delete-dialog/delete-dialog.component';
import { EditDialogComponent } from './Adminmovie/edit-dialog/edit-dialog.component';
import { DataTableComponent } from './Adminmovie/data-table/data-table.component';
import { AddDialogCustComponent } from './Admincustomer/add-dialog-cust/add-dialog-cust.component';
import { EditDialogCustComponent } from './Admincustomer/edit-dialog-cust/edit-dialog-cust.component';
import { DataDialogCustComponent } from './Admincustomer/data-dialog-cust/data-dialog-cust.component';
import { DeleteDialogCustComponent } from './Admincustomer/delete-dialog-cust/delete-dialog-cust.component';
import { PaypalcompComponent } from './paypalcomp/paypalcomp.component';



@NgModule({
  declarations: [
    AppComponent,
    AdminpageComponent,
    BookinggridComponent,
    CutomergridComponent,
    DefaultpageComponent,
    LoginpageComponent,
    MainbodyadminComponent,
    MainbodydefaultComponent,
    MoivegridComponent,
    NavadminComponent,
    NavuserComponent,
    OfferspageComponent,
    PaymentgriduserComponent,
    PaymentgridadminComponent,
    SeatbookingComponent,
    UserpageComponent,
    NavdeafultComponent,
    MainbodyuserComponent,
    MidpartComponent,
    OfferpagedefaultComponent,
    PaymentpageComponent,
    AddDialogComponent,
    DeleteDialogComponent,
    EditDialogComponent,
    DataTableComponent,
    AddDialogCustComponent,
    EditDialogCustComponent,
    DataDialogCustComponent,
    DeleteDialogCustComponent,
    PaypalcompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MatTableModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MatSnackBarModule,
    MatPaginatorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
