import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navadmin',
  templateUrl: './navadmin.component.html',
  styleUrls: ['./navadmin.component.css']
})
export class NavadminComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  validation(){
    this.route.navigate(['/home'])
  }


}
