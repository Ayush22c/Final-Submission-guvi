import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CutomergridComponent } from './cutomergrid.component';

describe('CutomergridComponent', () => {
  let component: CutomergridComponent;
  let fixture: ComponentFixture<CutomergridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CutomergridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CutomergridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
