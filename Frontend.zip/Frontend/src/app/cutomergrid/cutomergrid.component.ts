import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cutomergrid',
  templateUrl: './cutomergrid.component.html',
  styleUrls: ['./cutomergrid.component.css']
})
export class CutomergridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
