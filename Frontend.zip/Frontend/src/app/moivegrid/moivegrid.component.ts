import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moivegrid',
  templateUrl: './moivegrid.component.html',
  styleUrls: ['./moivegrid.component.css']
})
export class MoivegridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
