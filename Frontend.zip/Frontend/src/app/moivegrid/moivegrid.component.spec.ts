import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoivegridComponent } from './moivegrid.component';

describe('MoivegridComponent', () => {
  let component: MoivegridComponent;
  let fixture: ComponentFixture<MoivegridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoivegridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoivegridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
