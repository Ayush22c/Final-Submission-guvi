import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { DataService } from '../Services/data.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css'],
})
export class LoginpageComponent implements OnInit {
  emailData: string = '';
  password: string = '';
  found: boolean = false;

  name: string = '';
  phoneno: string = '';
  data: any;

  constructor(private route: Router, private obj: DataService) {}

  ngOnInit(): void {}
  datavalidation() {
    if (this.emailData == 'admin@watch.com' && this.password == '1234') {
      localStorage.setItem('admin',JSON.stringify([{"id":"admin"}]));
      this.route.navigate(['/admin']);
      console.log('Admin');
    } else {
      this.obj.getemailverify(this.emailData).subscribe((dataobj) => {
        console.log(dataobj);
        if (dataobj.length == 0) {
          alert('User Not Found... Please Sign Up... ');
        } else {
          console.log(dataobj[0].email);
          console.log(this.emailData);
          if (
            this.emailData === dataobj[0].email &&
            this.password === dataobj[0].password
          ) {
            this.obj.setData(dataobj);
            let navigationExtras: NavigationExtras = {
              state: dataobj[0],
            };
            localStorage.setItem('login',JSON.stringify(dataobj));
            this.route.navigate(['/user'], navigationExtras);
            console.log('User');
          } else {
            if (this.emailData !== dataobj[0].email) {
              alert('Email Wrong.....');
            } else {
              alert('Password wrong.....');
            }
          }
        }
      });
    }
  }

  datainsert() {
    this.data = {
      customer_name: this.name,
      email: this.emailData,
      phoneno: this.phoneno,
      password: this.password,
    };

    this.obj.getemailverify(this.emailData).subscribe((dataobj) => {
      console.log(dataobj);
      if (dataobj.length != 0) {
        this.found = true;
        alert('Already presented email.... change it!!!!!');
      } else {
        this.obj.postCustomerDetail(this.data).subscribe((data) => {
          console.log(data);

          alert('Data has been added....');
        });
      }
    });
  }
}
