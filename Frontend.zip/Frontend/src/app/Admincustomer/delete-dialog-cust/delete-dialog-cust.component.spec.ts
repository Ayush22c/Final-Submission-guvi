import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteDialogCustComponent } from './delete-dialog-cust.component';

describe('DeleteDialogCustComponent', () => {
  let component: DeleteDialogCustComponent;
  let fixture: ComponentFixture<DeleteDialogCustComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteDialogCustComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeleteDialogCustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
