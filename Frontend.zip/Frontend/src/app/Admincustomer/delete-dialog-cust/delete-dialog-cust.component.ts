import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-dialog-cust',
  templateUrl: './delete-dialog-cust.component.html',
  styleUrls: ['./delete-dialog-cust.component.css']
})
export class DeleteDialogCustComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<DeleteDialogCustComponent>) { }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close(false);
  }
  doneChange(){
    this.dialogRef.close(true);
  }

}
