import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { EditDialogComponent } from 'src/app/Adminmovie/edit-dialog/edit-dialog.component';

@Component({
  selector: 'app-edit-dialog-cust',
  templateUrl: './edit-dialog-cust.component.html',
  styleUrls: ['./edit-dialog-cust.component.css']
})
export class EditDialogCustComponent implements OnInit {

  rowData: any;

  constructor(@Inject(MAT_DIALOG_DATA) private data: any,private dialogRef: MatDialogRef<EditDialogComponent>) {
    this.rowData=data;
    console.log(this.rowData);

   }

  ngOnInit(): void {
  }

  cancelChange(){
    this.dialogRef.close();
  }
  doneChange(){
    this.dialogRef.close(this.rowData);
  }

}
