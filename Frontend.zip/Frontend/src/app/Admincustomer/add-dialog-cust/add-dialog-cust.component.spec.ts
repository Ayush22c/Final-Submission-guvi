import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDialogCustComponent } from './add-dialog-cust.component';

describe('AddDialogCustComponent', () => {
  let component: AddDialogCustComponent;
  let fixture: ComponentFixture<AddDialogCustComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDialogCustComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddDialogCustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
