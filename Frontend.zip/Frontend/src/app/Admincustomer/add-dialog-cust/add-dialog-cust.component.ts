import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-dialog-cust',
  templateUrl: './add-dialog-cust.component.html',
  styleUrls: ['./add-dialog-cust.component.css']
})
export class AddDialogCustComponent implements OnInit {

  morning:number=0;
  noon:number=0;
  evening:number=0;
  mornprice:number=0;
  noonprice:number=0;
  evenprice:number=0;
  UserData : any={
    id: '',
    movie_name:"",
	  seats:[],
    timings:["Morning","Noon","Evening"],
    ratings:"",
	  image:"",
	  price: [],
	  description: "",
	  genre: "",
	  language:"",
	  origin:"",
	  trailer:"",
  }
  constructor(private dialogRef: MatDialogRef<AddDialogCustComponent>) { }

  ngOnInit(): void {
  }

  cancelChange(){
    this.dialogRef.close({valid: false,value:this.UserData});
  }
  doneChange(){
    this.UserData.seats=[this.morning,this.noon,this.evening];
    this.UserData.price=[this.mornprice,this.noonprice,this.evenprice];
    this.dialogRef.close({valid: true,value:this.UserData});
  }

}
