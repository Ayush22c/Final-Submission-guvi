import { Component, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DeleteDialogComponent } from 'src/app/Adminmovie/delete-dialog/delete-dialog.component';
import { CustomerService } from 'src/app/Services/customer.service';
import { Data } from 'src/app/Utilites/customer';
import { User, UserColumns } from 'src/app/Utilites/admincustdata';
import { EditDialogCustComponent } from '../edit-dialog-cust/edit-dialog-cust.component';
import { AddDialogCustComponent } from '../add-dialog-cust/add-dialog-cust.component';

@Component({
  selector: 'app-data-dialog-cust',
  templateUrl: './data-dialog-cust.component.html',
  styleUrls: ['./data-dialog-cust.component.css']
})
export class DataDialogCustComponent implements OnInit {
  displayedColumns: string[] = UserColumns.map((col) => col.key);
  columnsSchema: any = UserColumns;
  dataSource = new MatTableDataSource<User>();
  valid: any = {};
  delete: boolean = false;
  edit: boolean = false;
  add: boolean = false;
  mulDel: boolean = false;
  idNew: number = 0;
  Selected:Data[]=[];
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(public dialog: MatDialog, private userService: CustomerService) { }

  ngOnInit() {
    this.userService.getUsers().subscribe((res: any) => {
      this.dataSource.data = res;
    });
  }
  ngAfterViewInit(){
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }
  ngOnChanges(changes: SimpleChanges): void {
      console.log(changes);
  }

  editRow(element: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = element;
    let dialogRef = this.dialog.open(EditDialogCustComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      (data) => {
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if(data!=undefined){
          this.userService.updateUser(data).subscribe((data: any) => {
            console.log(data);
          });
        }
        else{
          this.userService.getUsers().subscribe((res: any) => {
            this.dataSource.data = res;
          });
        }
      });
  }

  addRow() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(AddDialogCustComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data.value);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data.valid === true) {
          data.value.id = '1';
          if (this.dataSource.data.length > 0) {
            this.idNew = parseInt(this.dataSource.data[this.dataSource.data.length - 1].id) + 1;
            data.value.id= this.idNew.toString();
          }
          this.dataSource.data = [...this.dataSource.data, data.value];
          console.log(this.dataSource.data);
          this.userService.addUser(data.value).subscribe((data: any) => {
            console.log(data);
          });
        }
      });
  }


  removeRow(element: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return item.id !== element.id;
          });
          console.log(this.dataSource.data);
          this.userService.deleteUser(element.id).subscribe((data: any) => {
            console.log(data);
          });
        }
      });

  }

  removeSelectedRows() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.Selected=this.dataSource.data.filter(function (item) {
            return item.isSelected;
          });
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return !item.isSelected;
          });
          this.userService.deleteUsers(this.Selected).subscribe((data: any)=>{
             console.log(data);
          });
        }
      });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
