import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataDialogCustComponent } from './data-dialog-cust.component';

describe('DataDialogCustComponent', () => {
  let component: DataDialogCustComponent;
  let fixture: ComponentFixture<DataDialogCustComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataDialogCustComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DataDialogCustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
