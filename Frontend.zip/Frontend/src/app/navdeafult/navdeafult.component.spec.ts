import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavdeafultComponent } from './navdeafult.component';

describe('NavdeafultComponent', () => {
  let component: NavdeafultComponent;
  let fixture: ComponentFixture<NavdeafultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NavdeafultComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavdeafultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
