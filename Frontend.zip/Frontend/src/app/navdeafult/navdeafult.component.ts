import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navdeafult',
  templateUrl: './navdeafult.component.html',
  styleUrls: ['./navdeafult.component.css']
})
export class NavdeafultComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
