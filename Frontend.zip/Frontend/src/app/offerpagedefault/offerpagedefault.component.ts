import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offerpagedefault',
  templateUrl: './offerpagedefault.component.html',
  styleUrls: ['./offerpagedefault.component.css']
})
export class OfferpagedefaultComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
