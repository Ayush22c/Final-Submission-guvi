import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentgriduserComponent } from './paymentgriduser.component';

describe('PaymentgriduserComponent', () => {
  let component: PaymentgriduserComponent;
  let fixture: ComponentFixture<PaymentgriduserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentgriduserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentgriduserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
