import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {

  dataadmin:any;
  constructor(private route:Router) {
    this.dataadmin=JSON.parse(localStorage.getItem('admin')||'{}')
    console.log(this.dataadmin.length)
    if(this.dataadmin.length>0)
    {
      console.log("true const")

    }
    else{
      console.log("false const")
      this.route.navigate(['/loginpage'])
    }
  }

  ngOnInit(): void {
    this.dataadmin=JSON.parse(localStorage.getItem('admin')||'{}')
    console.log(this.dataadmin.length)
    if(this.dataadmin.length>0)
    {
      console.log(true)

    }
    else{
      console.log(false)
      this.route.navigate(['/loginpage'])
    }
  }

}
