import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../Services/data.service';
import { TicketData } from '../Utilites/TicketData';

@Component({
  selector: 'app-seatbooking',
  templateUrl: './seatbooking.component.html',
  styleUrls: ['./seatbooking.component.css']
})
export class SeatbookingComponent implements OnInit {

  product:any;
  data:any;
  data1:any;

  datalogin:any;
  datamovie:any;


  body:any;
  nameData:any;
  emailData:any;
  phonenoData:string='';
  noOfTicketData:number=0;
  totalticketData:number=0;
  showTimingData:number=-1;
  dateData:any;
  priceData:number=0;
  seats:number=0;

  dataForm= new TicketData

  constructor(private object:DataService) {
    // this.product=this.object.getCurrentNavigation()?.extras.state;
    // this.data=this.product.data
    // this.data1=this.product.data1
    // console.log(this.product)
    // console.log(this.data)
    // console.log(this.data1)

    // localStorage.setItem('movie',JSON.stringify(this.data));

     this.datalogin=JSON.parse(localStorage.getItem('login')||'{}')
     this.datamovie=JSON.parse(localStorage.getItem('movie')||'{}')
     console.log(this.datalogin[0])
     console.log(this.datamovie)

  }

  ngOnInit(): void {
  }

  onChange(event:any){
    this.showTimingData=parseInt(event.target.value);
    this.totalticketData=this.datamovie.seats[this.showTimingData];
    this.priceData=this.datamovie.price[this.showTimingData];
    this.totalticketData=this.totalticketData - this.noOfTicketData;
  }


  checker(): boolean{
    if(this.showTimingData == -1)
    return false;
    else return true;
  }



  datacopying(){
    this.seats=this.totalticketData - this.noOfTicketData
    this.dataForm.customer_id=this.datalogin[0].id;
    this.dataForm.customer_name=this.datalogin[0].customer_name;
    this.dataForm.movie_id=this.datamovie.id;
    this.dataForm.movie_name=this.datamovie.movie_name;
    this.dataForm.transactionno=Math.floor(Math.random() * (15000 - 11000 + 1)) + 11000;
    this.dataForm.bookingno= this.dataForm.transactionno;
    this.dataForm.paymenttype="Online"
    this.dataForm.show=this.showTimingData;
    this.dataForm.totalticket=this.noOfTicketData;
    this.dataForm.seatsleft=this.datamovie.seats;
    this.dataForm.seatsleft[this.showTimingData]=this.seats;
    this.dataForm.totaprice=this.priceData * this.noOfTicketData;
    this.dataForm.date=this.dateData;
    console.log(this.dataForm)
    localStorage.setItem('payment',JSON.stringify(this.dataForm));
    // this.object.insertPaymentDetail(this.dataForm).subscribe((data:TicketData[])=>{
    //   console.log(data)
    // })
  }

}
