import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Data } from '../Utilites/Data';
import { User } from '../Utilites/User';


@Injectable({
  providedIn: 'root',
})
export class UserService {
  private serviceUrl = 'http://localhost:4500/api';
  constructor(private http: HttpClient) { }

  getUsers(): Observable<Data[]> {
    return this.http
      .get(`${this.serviceUrl}/Movie/getdata`)
      .pipe<User[]>(map((data: any) => data));
  }

  updateUser(data: Data): Observable<Data> {
    console.log(data.id);
    return this.http.put<User>(`${this.serviceUrl}/Movie/update/${data.id}`, data);
  }

  addUser(data: Data): Observable<Data> {
    return this.http.post<User>(`${this.serviceUrl}/Movie/insert`, data);
  }

  deleteUser(id: number): Observable<Data> {
    return this.http.delete<User>(`${this.serviceUrl}/Movie/delete/${id}`);
  }

  deleteUsers(datas: any): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<User>(`${this.serviceUrl}/Movie/delete/${data.id}`)
      ));
  }
}
