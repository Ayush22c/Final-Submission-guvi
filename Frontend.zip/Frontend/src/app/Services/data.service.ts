import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { customerData } from '../Utilites/customerData';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  body: any;
  userData: customerData = {
    id: '',
    customer_name: '',
    email: '',
    phoneno: '',
    password: '',
  };

  private serviceUrl = 'http://localhost:4500/api';
  constructor(private httpClient: HttpClient) {}

  getMovieDetail(): Observable<any> {
    return this.httpClient
      .get<any>(`${this.serviceUrl}/Movie/getdata`)
      .pipe(retry(1), catchError(this.handleError));
  }

  updatedata(data: any, id: string): Observable<any> {
    this.body = {
      Seats: data,
    };
    console.log(this.body);
    return this.httpClient
      .put<any>(`${this.serviceUrl}/Movie/update/${id}`, this.body)
      .pipe(retry(1), catchError(this.handleError));
  }

  postCustomerDetail(data: any): Observable<any> {
    return this.httpClient
      .post<any>(`${this.serviceUrl}/Customer/insert`, data)
      .pipe(retry(1), catchError(this.handleError));
  }

  getemailverify(data: string): Observable<any> {
    return this.httpClient
      .get<any>(`${this.serviceUrl}/Customer/email/${data}`)
      .pipe(retry(1), catchError(this.handleError));
  }

  getPaymentById(id: string): Observable<any> {
    return this.httpClient
      .get<any>(`${this.serviceUrl}/Customer/getdata/customerid/${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }

  getPaymentDetail(): Observable<any> {
    return this.httpClient
      .get<any>(`${this.serviceUrl}/Payment/getdata`)
      .pipe(retry(1), catchError(this.handleError));
  }

  insertPaymentDetail(data: any): Observable<any> {
    return this.httpClient
      .post<any>(`${this.serviceUrl}/Paymemt/insert`, data)
      .pipe(retry(1), catchError(this.handleError));
  }

  setData(body: any) {
    this.userData.customer_name = body.customer_name;
    this.userData.id = body.id;
    this.userData.email = body.email;
    this.userData.phoneno = body.phoneno;
  }
  getData(): customerData {
    return this.userData;
  }

  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
