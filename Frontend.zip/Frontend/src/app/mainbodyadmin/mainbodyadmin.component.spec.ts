import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainbodyadminComponent } from './mainbodyadmin.component';

describe('MainbodyadminComponent', () => {
  let component: MainbodyadminComponent;
  let fixture: ComponentFixture<MainbodyadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainbodyadminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MainbodyadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
