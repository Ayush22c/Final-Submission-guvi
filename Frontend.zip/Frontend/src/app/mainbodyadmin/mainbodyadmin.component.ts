import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainbodyadmin',
  templateUrl: './mainbodyadmin.component.html',
  styleUrls: ['./mainbodyadmin.component.css']
})
export class MainbodyadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
