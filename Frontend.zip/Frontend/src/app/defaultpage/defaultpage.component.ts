import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultpage',
  templateUrl: './defaultpage.component.html',
  styleUrls: ['./defaultpage.component.css']
})
export class DefaultpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    localStorage.setItem('login',JSON.stringify({}));
    localStorage.setItem('movie',JSON.stringify({}));
    localStorage.setItem('admin',JSON.stringify({}));
    localStorage.setItem('payment',JSON.stringify({}));
  }

}
