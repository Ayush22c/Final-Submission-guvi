import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentgridadminComponent } from './paymentgridadmin.component';

describe('PaymentgridadminComponent', () => {
  let component: PaymentgridadminComponent;
  let fixture: ComponentFixture<PaymentgridadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentgridadminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentgridadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
