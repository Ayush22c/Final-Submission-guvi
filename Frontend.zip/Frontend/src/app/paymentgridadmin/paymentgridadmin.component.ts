import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DataService } from '../Services/data.service';
import { PaymentColumns, PaymentData } from '../Utilites/PaymentData';

@Component({
  selector: 'app-paymentgridadmin',
  templateUrl: './paymentgridadmin.component.html',
  styleUrls: ['./paymentgridadmin.component.css']
})
export class PaymentgridadminComponent implements OnInit {
  displayedColumns: string[] = PaymentColumns.map((col) => col.key);
  columnsSchema: any = PaymentColumns;
  dataSource = new MatTableDataSource<PaymentData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private service: DataService) { }

  ngOnInit(): void {
    this.service.getPaymentDetail().subscribe((data: any)=>{
      console.log(data);
      this.dataSource.data=data;
    })
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
