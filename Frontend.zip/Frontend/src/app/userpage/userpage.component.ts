import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {


  datauser:any;
  constructor(private route:Router) {
    localStorage.setItem('payment',JSON.stringify({}));
    this.datauser=JSON.parse(localStorage.getItem('login')||'{}')
    console.log(this.datauser.length)
    if(this.datauser.length>0)
    {
      console.log("true const")

    }
    else{
      console.log("false const")
      this.route.navigate(['/loginpage'])
    }
  }

  ngOnInit(): void {
    localStorage.setItem('payment',JSON.stringify({}));
    this.datauser=JSON.parse(localStorage.getItem('login')||'{}')
    console.log(this.datauser.length)
    if(this.datauser.length>0)
    {
      console.log("true const")

    }
    else{
      console.log("false const")
      this.route.navigate(['/loginpage'])
    }
  }

}
