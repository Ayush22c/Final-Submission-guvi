export interface User {
  isSelected: boolean;
  id:string;
  customer_name: string;
  email:string;
  phoneno: string;
  password:string;
  isEdit: boolean;
}

export const UserColumns = [
  {
    key: 'isSelected',
    type: 'isSelected',
    label: '',
  },
  {
    key: 'customer_name',
    type: 'text',
    label: 'Customer Name',
    required: true,
  },
  {
    key: 'email',
    type: 'text',
    label: 'Email',
    required: true,
  },
  {
    key: 'phoneno',
    type: 'text',
    label: 'phoneno',
    required: true,
  },


  {
    key: 'isEdit',
    type: 'isEdit',
    label: '',
  },
];
