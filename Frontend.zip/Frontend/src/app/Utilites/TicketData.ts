export class TicketData {
  customer_id:string="";
  customer_name:string="";
  movie_id:string="";
  movie_name:string="";
  transactionno:number=0;
  bookingno:number=0;
  paymenttype:string="";
  show:number=-1;
  totalticket:number=0;
  seatsleft:any=[];
  totaprice:number=0;
  date:string="";
}
