export interface Data {
    id: string;
    movie_name: string;
    ratings: string;
    language: string;
    genre: string;
    origin:string;
    price:any;
    seats:any;
  }
