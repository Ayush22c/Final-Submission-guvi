export interface User {
    isSelected: boolean;
    id:string;
    movie_name:string;
	  seats:any;
    timings:["Morning","Noon","Evening"];
    ratings:string;
	  image:string;
	  price:any;
	  description:string;
	  genre: string;
	  language:string;
	  origin:string;
	  trailer:string;
    isEdit: boolean;
  }

  export const UserColumns = [
    {
      key: 'isSelected',
      type: 'isSelected',
      label: '',
    },
    {
      key: 'movie_name',
      type: 'text',
      label: 'Movie Name',
      required: true,
    },
    {
      key: 'ratings',
      type: 'text',
      label: 'Ratings',
      required: true,
    },
    {
      key: 'language',
      type: 'text',
      label: 'Language',
      required: true,
    },
    {
      key:'genre',
      type:'number',
      label:'Genre',
      required: true,

    },
    {
      key:'origin',
      type:'number',
      label:'Origin',
      required: true,

    },
    {
      key:'price',
      type:'number',
      label:'Price',
      required: true,

    },
    {
      key:'seats',
      type:'number',
      label:'Seats',
      required: true,

    },

    {
      key: 'isEdit',
      type: 'isEdit',
      label: '',
    },
  ];
