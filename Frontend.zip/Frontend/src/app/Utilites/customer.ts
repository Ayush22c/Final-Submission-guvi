export interface Data {
  id: string;
  customer_name: string;
  email:string;
  phoneno: string;
  password:string;
}
