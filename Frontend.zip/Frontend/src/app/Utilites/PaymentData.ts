
export interface PaymentData{
  id: string;
  paymentid:string;
  username: string;
  totalPrice: number;
  paymentmode: string;
  paymentstatus: string;
}

export const PaymentColumns = [
  {
    key: 'date',
    type: 'text',
    label: 'Date',
    required: true,
},
  {
    key:'transactionno',
    type: 'text',
    label: 'Transaction Id',
    required: true,
  },
  {
    key:'movie_name',
    type: 'text',
    label: 'Movie Name',
    required: true,
  },
  {
    key: 'paymenttype',
    type: 'text',
    label: 'Payment Type',
    required: true,
  },
  {
    key: 'totalticket',
    type: 'number',
    label: 'Total Ticket',
    required: true,
  },

  {
    key: 'totaprice',
    type: 'string',
    label: 'Total Price ( Rs. )',
    required: true,
  }

];


export const BookingColumns = [
  {
    key: 'date',
    type: 'text',
    label: 'Date',
    required: true,
},
{
  key: 'bookingno',
  type: 'text',
  label: 'Booking Id',
  required: true,
},
  {
    key:'transactionno',
    type: 'text',
    label: 'Transaction Id',
    required: true,
  },
  {
    key:'customer_name',
    type: 'text',
    label: 'User Name',
    required: true,
  },
  {
    key:'movie_name',
    type: 'text',
    label: 'Movie Name',
    required: true,
  },

  {
    key: 'totalticket',
    type: 'number',
    label: 'Total Ticket',
    required: true,
  },



  {
    key: 'totaprice',
    type: 'string',
    label: 'Total Price ( Rs. )',
    required: true,
  }

];
