export interface customerData {
  id: string;
  customer_name: string;
  email:string;
  phoneno:string;
  password:string;

}


export const UserColumns = [
  {
    key: 'name',
    type: 'text',
    label: 'Name',
  },
  {
    key: 'moiveName',
    type: 'text',
    label: 'Movie Name',
  },
  {
    key: 'noOfTicket',
    type: 'number',
    label: 'Seats',
  },
  {
    key:'totalprice',
    type:'number',
    label:'Total Price'
  },
  {
    key: 'isEdit',
    type: 'isEdit',
    label: '',
  },
];
