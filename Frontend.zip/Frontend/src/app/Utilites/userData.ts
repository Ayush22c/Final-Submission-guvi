export interface UserData {
  id: string;
  moiveid: string;
  name: string;
  moiveName: string;
  noOfTicket: number;
  isEdit: boolean;
  seats: any;
  timing: any;
  ticketsavl: number;
  totalprice:number;
  singleprice: number ;

}

export const UserColumns = [
  {
    key: 'name',
    type: 'text',
    label: 'Name',
  },
  {
    key: 'moiveName',
    type: 'text',
    label: 'Movie Name',
  },
  {
    key: 'noOfTicket',
    type: 'number',
    label: 'Seats',
  },
  {
    key:'totalprice',
    type:'number',
    label:'Total Price'
  },
  {
    key: 'isEdit',
    type: 'isEdit',
    label: '',
  },
];
