import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navuser',
  templateUrl: './navuser.component.html',
  styleUrls: ['./navuser.component.css']
})
export class NavuserComponent implements OnInit {

  @Input() item:any;

  constructor(private route:Router) {
  }

  ngOnInit(): void {

  }

  valid(){
    this.route.navigate(['/home'])


  }

}
