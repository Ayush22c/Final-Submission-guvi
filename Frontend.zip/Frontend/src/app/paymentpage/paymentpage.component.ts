import { Component, OnInit } from '@angular/core';
import { DataService } from '../Services/data.service';
import { TicketData } from '../Utilites/TicketData';

@Component({
  selector: 'app-paymentpage',
  templateUrl: './paymentpage.component.html',
  styleUrls: ['./paymentpage.component.css']
})
export class PaymentpageComponent implements OnInit {
  datapayment: any;

  constructor(private object:DataService) {
    this.datapayment=JSON.parse(localStorage.getItem('payment')||'{}')
   }

  ngOnInit(): void {
    this.object.insertPaymentDetail(this.datapayment).subscribe((data:TicketData[])=>{
      console.log(data)
    })
  }

}
