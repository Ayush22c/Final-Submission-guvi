package com.backend.Code.DBModel;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


/**
 * @author AYSRIV0
 *
 */
@Document(collection = "CustomerList")

public class Pojocustomerlist {
	
	@Id
	  private String id;
	 
	 @Field(name = "customer_name")
	  private String customer_name;
	 
	 @Field(name = "email")
	  private String email;
	 
	 @Field(name = "phoneno")
	  private String phoneno;
	 
	 @Field(name = "password")
	  private String password;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Pojocustomerlist(String customer_name, String email, String phoneno, String password) {
		
		this.customer_name = customer_name;
		this.email = email;
		this.phoneno = phoneno;
		this.password = password;
	}
	 
	
}
