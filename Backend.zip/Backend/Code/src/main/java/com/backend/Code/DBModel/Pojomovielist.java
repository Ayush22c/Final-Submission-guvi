package com.backend.Code.DBModel;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


/**
 * @author AYSRIV0
 *
 */
@Document(collection = "MovieList")
public class Pojomovielist {
	
	 @Id
	  private String id;
	 
	 @Field(name = "movie_name")
	  private String movie_name;
	 
	 @Field(name = "seats")
	  private List<Integer> seats;
	 
	 @Field(name = "timings")
	  private List<String> timings;
	 
	 @Field(name = "ratings")
	  private String ratings;
	 
	 @Field(name = "image")
	  private String image;
	 
	 @Field(name = "price")
	  private List<Integer> price;
	 
	 @Field(name = "description")
	  private String description;
	 
	 @Field(name = "genre")
	  private String genre;
	 
	 @Field(name = "langauge")
	  private String language;
	 
	 @Field(name = "origin")
	  private String origin;
	 
	 @Field(name = "trailer")
	  private String trailer;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMovie_name() {
		return movie_name;
	}

	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	public List<Integer> getSeats() {
		return seats;
	}

	public void setSeats(List<Integer> seats) {
		this.seats = seats;
	}

	public List<String> getTimings() {
		return timings;
	}

	public void setTimings(List<String> timings) {
		this.timings = timings;
	}

	public String getRatings() {
		return ratings;
	}

	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public List<Integer> getPrice() {
		return price;
	}

	public void setPrice(List<Integer> price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getTrailer() {
		return trailer;
	}

	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}

	public Pojomovielist(String movie_name, List<Integer> seats, List<String> timings, String ratings, String image,
			List<Integer> price, String description, String genre, String language, String origin, String trailer) {

		this.movie_name = movie_name;
		this.seats = seats;
		this.timings = timings;
		this.ratings = ratings;
		this.image = image;
		this.price = price;
		this.description = description;
		this.genre = genre;
		this.language = language;
		this.origin = origin;
		this.trailer = trailer;
	}
	 
	 
	 
	 
	 
	 

}
