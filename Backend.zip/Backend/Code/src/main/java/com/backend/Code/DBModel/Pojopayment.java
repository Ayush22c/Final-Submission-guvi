package com.backend.Code.DBModel;



import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author AYSRIV0
 *
 */
@Document(collection = "Paymenthistory")

public class Pojopayment {
	
	@Id
	  private String id;
	
	 @Field(name = "customer_id")
	  private String customer_id;
	 
	 @Field(name = "customer_name")
	  private String customer_name;
	 
	 
	 @Field(name = "movie_id")
	  private String movie_id;
	 
	 @Field(name = "movie_name")
	  private String movie_name;

	@Field(name = "transactionno")
	  private String transactionno;
	 
	 


	@Field(name = "bookingno")
	  private String bookingno;
	 
	 @Field(name = "paymenttype")
	  private String paymenttype;
	 

	 @Field(name = "showtiming")
	  private int show;
	 
	 @Field(name = "totalticket")
	  private int totalticket;
	 
	 @Field(name = "seatsleft")
	  private List<Integer> seatsleft ;
	 
	 @Field(name = "totalprice")
	  private int totaprice;
	 
	 
	 @Field(name = "date")
	  private String date;
	 
	 
//	 public Pojopayment(String customer_id, String movie_id, String transactionno, String bookingno, String paymenttype,
//				int show, int totalticket, List<Integer> seatsleft, int totaprice, String date) {
//			this.customer_id = customer_id;
//			this.movie_id = movie_id;
//			this.transactionno = transactionno;
//			this.bookingno = bookingno;
//			this.paymenttype = paymenttype;
//			this.show = show;
//			this.totalticket = totalticket;
//			this.seatsleft = seatsleft;
//			this.totaprice = totaprice;
//			this.date = date;
	 
//		}

	 public String getId() {
			return id;
		}


		public void setId(String id) {
			this.id = id;
		}


		public String getCustomer_id() {
			return customer_id;
		}


		public void setCustomer_id(String customer_id) {
			this.customer_id = customer_id;
		}


		public String getMovie_id() {
			return movie_id;
		}


		public void setMovie_id(String movie_id) {
			this.movie_id = movie_id;
		}


		public String getTransactionno() {
			return transactionno;
		}


		public void setTransactionno(String transactionno) {
			this.transactionno = transactionno;
		}


		public String getBookingno() {
			return bookingno;
		}


		public void setBookingno(String bookingno) {
			this.bookingno = bookingno;
		}


		public String getPaymenttype() {
			return paymenttype;
		}


		public void setPaymenttype(String paymenttype) {
			this.paymenttype = paymenttype;
		}


		public int getShow() {
			return show;
		}


		public void setShow(int show) {
			this.show = show;
		}


		public int getTotalticket() {
			return totalticket;
		}


		public void setTotalticket(int totalticket) {
			this.totalticket = totalticket;
		}


		public List<Integer> getSeatsleft() {
			return seatsleft;
		}


		public void setSeatsleft(List<Integer> seatsleft) {
			this.seatsleft = seatsleft;
		}


		public int getTotaprice() {
			return totaprice;
		}


		public void setTotaprice(int totaprice) {
			this.totaprice = totaprice;
		}


		public String getDate() {
			return date;
		}


		public void setDate(String date) {
			this.date = date;
		}


		public String getCustomer_name() {
			return customer_name;
		}


		public void setCustomer_name(String customer_name) {
			this.customer_name = customer_name;
		}


		public String getMovie_name() {
			return movie_name;
		}


		public void setMovie_name(String movie_name) {
			this.movie_name = movie_name;
		}


		public Pojopayment(String customer_id, String customer_name, String movie_id, String movie_name,
				String transactionno, String bookingno, String paymenttype, int show, int totalticket,
				List<Integer> seatsleft, int totaprice, String date) {
			
			this.customer_id = customer_id;
			this.customer_name = customer_name;
			this.movie_id = movie_id;
			this.movie_name = movie_name;
			this.transactionno = transactionno;
			this.bookingno = bookingno;
			this.paymenttype = paymenttype;
			this.show = show;
			this.totalticket = totalticket;
			this.seatsleft = seatsleft;
			this.totaprice = totaprice;
			this.date = date;
		}

		

}
