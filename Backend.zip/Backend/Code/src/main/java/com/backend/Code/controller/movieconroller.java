package com.backend.Code.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.Code.DBModel.*;
import com.backend.Code.Repository.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")


public class movieconroller {

	@Autowired
	MovieListRepo MovieListRepo;
	


	@GetMapping("/Movie/{id}")
	public ResponseEntity<Pojomovielist> getCustomerById(@PathVariable("id") String id) {
		Optional<Pojomovielist> movieobj = MovieListRepo.findById(id);

		if (movieobj.isPresent()) {
			return new ResponseEntity<>(movieobj.get(), HttpStatus.OK);
			
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/Movie/getdata")
	public ResponseEntity<List<Pojomovielist>> getAllItems(){
		List<Pojomovielist> array=MovieListRepo.findAll();
		return new ResponseEntity<> (array,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/Movie/latest")
	public ResponseEntity<List<Pojomovielist>> getLatestMovie(){
		List<Pojomovielist> obj=MovieListRepo.findByProductStatus("Latest");
		return new ResponseEntity<> (obj,HttpStatus.OK);
	}

	@PostMapping("/Movie/insert")
	public ResponseEntity<Pojomovielist> createCustomer(@RequestBody Pojomovielist Pojomovie) {
		try {

			Pojomovielist _Pojomovie = MovieListRepo
					.save(new Pojomovielist(Pojomovie.getMovie_name(), Pojomovie.getSeats(), Pojomovie.getTimings(),Pojomovie.getRatings(),
							Pojomovie.getImage(),Pojomovie.getPrice(),Pojomovie.getDescription(),Pojomovie.getGenre(),
							Pojomovie.getLanguage(),Pojomovie.getOrigin(),Pojomovie.getTrailer()));
			return new ResponseEntity<>(_Pojomovie, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/Movie/update/{id}")
	public ResponseEntity<Pojomovielist> updateduser(@PathVariable String id,@RequestBody Pojomovielist newdetails){
		Optional<Pojomovielist> result=MovieListRepo.findById(id);
		if(result.isPresent()) {
			Pojomovielist  obj=result.get();
			obj.setMovie_name(newdetails.getMovie_name());
			obj.setSeats(newdetails.getSeats());
			obj.setTimings(newdetails.getTimings());
			obj.setRatings(newdetails.getRatings());
			obj.setImage(newdetails.getImage());
			obj.setPrice(newdetails.getPrice());
			obj.setDescription(newdetails.getDescription());
			obj.setGenre(newdetails.getGenre());
			obj.setLanguage(newdetails.getLanguage());
			obj.setOrigin(newdetails.getOrigin());
			obj.setTrailer(newdetails.getTrailer());
			
			
			Pojomovielist updatedata=MovieListRepo.save(obj);
			return new ResponseEntity<> (updatedata,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}


	@DeleteMapping("/Movie/delete/{id}")
	public ResponseEntity<HttpStatus> deleteMovieByid(@PathVariable("id") String id) {
		try {
			MovieListRepo.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	
	
}
