package com.backend.Code.Repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.backend.Code.DBModel.*;

public interface MovieListRepo extends MongoRepository<Pojomovielist,String> {
	
	@Query("{productStatus: ?0}")
	List<Pojomovielist> findByProductStatus(String productStatus);


}
