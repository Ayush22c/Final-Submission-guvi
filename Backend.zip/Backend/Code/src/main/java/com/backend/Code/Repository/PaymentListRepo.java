package com.backend.Code.Repository;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.backend.Code.DBModel.*;

public interface PaymentListRepo extends MongoRepository<Pojopayment,String> {
	


	@Query("{customer_id:?0}")
	List<Pojopayment> findByEmail(String email);
}
