package com.backend.Code.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.backend.Code.DBModel.*;
import com.backend.Code.Repository.*;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")

public class customercontroller {
	
	@Autowired
	CustomerListRepo CustomerListRepo;

	@GetMapping("/Customer/email/{email}")
	public ResponseEntity<List<Pojocustomerlist>> emailverify(@PathVariable("email") String email){
		List<Pojocustomerlist> array=CustomerListRepo.findByEmail(email);
		return ResponseEntity.ok(array);
	}
	
	@GetMapping("/Customer/{id}")
	public ResponseEntity<Pojocustomerlist> getCustomerById(@PathVariable("id") String id) {
		Optional<Pojocustomerlist> customerobj = CustomerListRepo.findById(id);

		if (customerobj.isPresent()) {
			return new ResponseEntity<>(customerobj.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/Customer/getdata")
	public ResponseEntity<List<Pojocustomerlist>> getAllItems(){
		List<Pojocustomerlist> array=CustomerListRepo.findAll();
		return new ResponseEntity<> (array,HttpStatus.ACCEPTED);
	}

	@PostMapping("/Customer/insert")
	public ResponseEntity<Pojocustomerlist> createCustomer(@RequestBody Pojocustomerlist Pojocustomer) {
		try {
			Pojocustomerlist _Pojocustomer = CustomerListRepo
					.save(new Pojocustomerlist(Pojocustomer.getCustomer_name(), Pojocustomer.getEmail(), Pojocustomer.getPhoneno(),Pojocustomer.getPassword()));
			return new ResponseEntity<>(_Pojocustomer, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/Customer/update/{id}")
	public ResponseEntity<Pojocustomerlist> updateduser(@PathVariable String id,@RequestBody Pojocustomerlist newdetails){
		Optional<Pojocustomerlist> result=CustomerListRepo.findById(id);
		if(result.isPresent()) {
			Pojocustomerlist  obj=result.get();
			obj.setCustomer_name(newdetails.getCustomer_name());
			obj.setEmail(newdetails.getEmail());
			obj.setPhoneno(newdetails.getPhoneno());
			obj.setPassword(newdetails.getPassword());
			Pojocustomerlist updatedata=CustomerListRepo.save(obj);
			return new ResponseEntity<> (updatedata,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}


	@DeleteMapping("/Customer/delete/{id}")
	public ResponseEntity<HttpStatus> deleteCustomer(@PathVariable("id") String id) {
		try {
			CustomerListRepo.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/Customer/deleteAll")
	public ResponseEntity<HttpStatus> deleteAllCustomer() {
		try {
			CustomerListRepo.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	


}
